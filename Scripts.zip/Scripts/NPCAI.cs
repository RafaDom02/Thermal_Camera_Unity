using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.AI; //important (without this the project will explode)

public class NPCAI : MonoBehaviour //don't forget to change the script name if you haven't
{
    public NavMeshAgent agent; //NPC agent
    public float range; //radius of sphere for new position
    public Transform centrePoint; //centre of the area the agent wants to move around in

    void Start()
    {
        agent = GetComponent<NavMeshAgent>();
    }

    
    void Update()
    {
        if(agent.remainingDistance <= agent.stoppingDistance) //checks if the last path is completed
        {
            Vector3 point;
            if (RandomPoint(centrePoint.position, range, out point)) //creates a new point to move to
            {
                Debug.DrawRay(point, Vector3.up, Color.blue, 1.0f); //to see where the NPC is going to move to (comment in final version)
                agent.SetDestination(point); //set the new position to the NPC 
            }
        }

    }
    bool RandomPoint(Vector3 center, float range, out Vector3 result)
    {

        Vector3 randomPoint = center + Random.insideUnitSphere * range; //random point with the sphere range given
        NavMeshHit hit;
        if (NavMesh.SamplePosition(randomPoint, out hit, 1.0f, NavMesh.AllAreas))   //documentation: https://docs.unity3d.com/ScriptReference/AI.NavMesh.SamplePosition.html
        {                                                                           //the 1.0f is the max distance from the random point to a point on the navmesh, might want to increase if range is big
                                                                                    //or add a for loop like in the documentation
            result = hit.position;
            return true;
        }

        result = Vector3.zero; //In case of an error
        return false;
    }

    
}
