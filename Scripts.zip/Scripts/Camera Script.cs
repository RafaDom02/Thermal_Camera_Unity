using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using Cinemachine;

public class CameraScript : MonoBehaviour
{
    [SerializeField] private CinemachineVirtualCamera cinemachineVirtualCamera;

    private float targetFieldOfView = 50;
    [SerializeField] private float FieldOfViewMin = 10;
    [SerializeField] private float FieldOfViewMax = 60;


    public float moveSpeed;
    public float rotateSpeed;

    // Start is called before the first frame update
    void Start()
    {
        
    }

    // Update is called once per frame
    private void Update()
    {
        HandleCameraMovement();

        HandleCameraRotation();

        HandleCameraZoom();
    }

    private void HandleCameraMovement(){
        Vector3 inputDir = new Vector3(0,0,0);
        Vector3 moveDir;

        if (Input.GetKey(KeyCode.W)) inputDir.x = +1f;
        if (Input.GetKey(KeyCode.A)) inputDir.z = +1f;
        if (Input.GetKey(KeyCode.S)) inputDir.x = -1f;
        if (Input.GetKey(KeyCode.D)) inputDir.z = -1f;
        if (Input.GetKey(KeyCode.LeftShift)) inputDir.y = -1f;
        if (Input.GetKey(KeyCode.Space)) inputDir.y = +1f;

        moveDir = transform.forward * inputDir.z + transform.right * inputDir.x + transform.up * inputDir.y;

        transform.position += moveDir * moveSpeed * Time.deltaTime;

    }

    private void HandleCameraRotation(){
        float rotateDir = 0f;

        if (Input.GetKey(KeyCode.Q)) rotateDir = +1f;
        if (Input.GetKey(KeyCode.E)) rotateDir = -1f;

        transform.eulerAngles += new Vector3(0, rotateDir * rotateSpeed * Time.deltaTime, 0);
    }

    private void HandleCameraZoom(){
        float zoomSpeed = 10f;

        if(Input.mouseScrollDelta.y < 0)
            targetFieldOfView += 5;
        if(Input.mouseScrollDelta.y > 0)
            targetFieldOfView -= 5;

        targetFieldOfView = Mathf.Clamp(targetFieldOfView, FieldOfViewMin, FieldOfViewMax);
        cinemachineVirtualCamera.m_Lens.FieldOfView =
            Mathf.Lerp(cinemachineVirtualCamera.m_Lens.FieldOfView, targetFieldOfView, Time.deltaTime * zoomSpeed);
    }
}
